<?php echo e($slot); ?>

<?php /**PATH /home/cuohyffq/ai.sitevity.com/resources/views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>