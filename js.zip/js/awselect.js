$(function(e) {

    "use strict";
      
      /*===========================================================================
      *
      *  CONFIGURATION DROPDOWN MENUS 
      *
      *============================================================================*/
      $(document).ready(function(){

          $('#response-status').awselect();

          $('#user-country').awselect();

          $('#user-role').awselect();

          $('#date-format').awselect();

          $('#template-selection').awselect();

          $('#language').awselect();

          $('#languages').awselect();

          $('#voices').awselect();

          $('#del-project').awselect();

          $('#set-project').awselect();

          $('#templates-streaming').awselect();

      }); 
  
  });
  
  
  