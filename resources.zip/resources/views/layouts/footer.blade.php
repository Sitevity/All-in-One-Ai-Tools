<!-- FOOTER -->
<footer class="footer">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-12 col-sm-12 text-center">
                {{ __('Copyright') }} © {{ date("Y") }} <a href="{{ config('app.url') }}">{{ config('app.name') }}</a>. {{ __('All rights reserved') }}
            </div>
            <div class="col-md-12 col-sm-12 text-center">
                <span class="fs-10 font-weight-bold text-info">{{ config('app.version') }}</span>
            </div>
        </div>
    </div>
</footer>
<!-- END FOOTER -->
