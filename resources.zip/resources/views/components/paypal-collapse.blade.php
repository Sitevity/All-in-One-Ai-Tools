<div class="text-center pb-2">
    <small class="text-muted fs-12 pl-4 pr-4 mb-2">{{ __('In order complete your Checkout Process you will be redirected to PayPal Website') }}.</small>
</div>